﻿using Microsoft.AspNetCore.Mvc;

namespace Perwalian.Controllers
{
    public class DashboardAdminController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}

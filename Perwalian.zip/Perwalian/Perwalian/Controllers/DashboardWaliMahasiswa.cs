﻿using Microsoft.AspNetCore.Mvc;

namespace Perwalian.Controllers
{
    public class DashboardWaliMahasiswa : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
